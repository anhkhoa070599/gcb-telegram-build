# Bot

This bot is an example how to send notification from Google Cloud Build using Telegram.

The code is explained in this blog article https://sylvainleroy.com/2019/12/10/how-to-send-telegram-notifications-with-google-cloud-build-gcb/

